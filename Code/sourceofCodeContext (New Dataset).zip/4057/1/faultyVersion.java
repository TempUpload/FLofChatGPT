import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner cin=new Scanner(System.in);

        int a=cin.nextInt();
        System.out.println(a*10);
    }
}